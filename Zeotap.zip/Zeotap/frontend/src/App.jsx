// src/App.jsx
import { useState } from 'react';
import SourceSelector from './components/SourceSelector';
import ConnectionForm from './components/ConnectionForm';
import ColumnSelector from './components/ColumnSelector';
import StatusDisplay from './components/StatusDisplay';
import './styles/app.css';

function App() {
  const [sourceType, setSourceType] = useState('');
  const [targetType, setTargetType] = useState('');
  const [config, setConfig] = useState({});
  const [columns, setColumns] = useState([]);
  const [status, setStatus] = useState('');
  const [recordCount, setRecordCount] = useState(null);
  const [error, setError] = useState(null);

  const handleIngestion = async () => {
    setStatus('Ingesting...');
    setError(null);
    setRecordCount(null);

    try {
      const response = await fetch('http://localhost:8080/api/ingest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceType,
          targetType,
          config,
          selectedColumns: columns,
        }),
      });

      if (!response.ok) throw new Error('Ingestion failed');

      const result = await response.json();
      setStatus('Completed');
      setRecordCount(result.recordsProcessed || 0);
    } catch (err) {
      setStatus('Error');
      setError(err.message);
    }
  };

  return (
    <div className="app-container">
      <h1>📊 Data Ingestion Tool</h1>

      <div className="card">
        <SourceSelector
          sourceType={sourceType}
          setSourceType={setSourceType}
          targetType={targetType}
          setTargetType={setTargetType}
        />
      </div>

      {sourceType && (
        <div className="card">
          <ConnectionForm
            sourceType={sourceType}
            targetType={targetType}
            config={config}
            setConfig={setConfig}
          />
        </div>
      )}

      {sourceType && (
        <div className="card">
          <ColumnSelector columns={columns} setColumns={setColumns} />
        </div>
      )}

      <div className="card center">
        <button className="ingest-btn" onClick={handleIngestion}>
          🚀 Start Ingestion
        </button>
      </div>

      <div className="card">
        <StatusDisplay status={status} recordCount={recordCount} error={error} />
      </div>
    </div>
  );
}

export default App;
