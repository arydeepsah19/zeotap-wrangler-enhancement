// src/components/StatusDisplay.jsx
function StatusDisplay({ status, recordCount, error }) {
    return (
      <div>
        <h2>Ingestion Status</h2>
        {status && <p className="status-message">Status: {status}</p>}
        {recordCount !== null && (
          <p className="status-message success">✅ Records Ingested: {recordCount}</p>
        )}
        {error && <p className="status-message error">❌ Error: {error}</p>}
      </div>
    );
  }
  
  export default StatusDisplay;
  