// src/components/ConnectionForm.jsx
import { useState, useEffect } from 'react';

function ConnectionForm({ sourceType, targetType, config, setConfig }) {
  const [localConfig, setLocalConfig] = useState({});

  useEffect(() => {
    setConfig(localConfig);
  }, [localConfig]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLocalConfig(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div>
      <h2>2. Configure Connection</h2>

      {sourceType === "ClickHouse" && (
        <>
          <input name="clickHouseConfig.host" placeholder="Host (e.g., https://localhost)" onChange={handleChange} />
          <input name="clickHouseConfig.port" placeholder="Port (e.g., 8443)" onChange={handleChange} />
          <input name="clickHouseConfig.database" placeholder="Database" onChange={handleChange} />
          <input name="clickHouseConfig.user" placeholder="User" onChange={handleChange} />
          <input name="clickHouseConfig.jwtToken" placeholder="JWT Token" onChange={handleChange} />
          <input name="tableName" placeholder="Table Name" onChange={handleChange} />
        </>
      )}

      {sourceType === "FlatFile" && (
        <>
          <input name="flatFileConfig.fileName" placeholder="CSV File Name (e.g., data.csv)" onChange={handleChange} />
          <input name="flatFileConfig.delimiter" placeholder="Delimiter (e.g., , or |)" onChange={handleChange} />
        </>
      )}
    </div>
  );
}

export default ConnectionForm;
