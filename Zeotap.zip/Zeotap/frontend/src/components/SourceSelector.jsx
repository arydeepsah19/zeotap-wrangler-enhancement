// src/components/SourceSelector.jsx
function SourceSelector({ sourceType, setSourceType, targetType, setTargetType }) {
    return (
      <div>
        <h2>1. Select Source & Target</h2>
  
        <label>Source:</label>
        <select value={sourceType} onChange={(e) => setSourceType(e.target.value)}>
          <option value="">-- Select --</option>
          <option value="ClickHouse">ClickHouse</option>
          <option value="FlatFile">Flat File</option>
        </select>
  
        <label>Target:</label>
        <select value={targetType} onChange={(e) => setTargetType(e.target.value)}>
          <option value="">-- Select --</option>
          <option value="ClickHouse">ClickHouse</option>
          <option value="FlatFile">Flat File</option>
        </select>
      </div>
    );
  }
  
  export default SourceSelector;
  