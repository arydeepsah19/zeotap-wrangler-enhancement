// src/components/ColumnSelector.jsx
// import { useEffect, useState } from 'react';

// function ColumnSelector({ columns, setColumns }) {
//   const [availableColumns, setAvailableColumns] = useState([
//     'id', 'name', 'email', 'amount', 'created_at' // 🧪 Simulated
//   ]);

//   const handleCheckboxChange = (column) => {
//     setColumns((prev) =>
//       prev.includes(column)
//         ? prev.filter((col) => col !== column)
//         : [...prev, column]
//     );
//   };

//   return (
//     <div>
//       <h2>3. Select Columns</h2>
//       {availableColumns.map((col) => (
//         <div key={col}>
//           <input
//             type="checkbox"
//             checked={columns.includes(col)}
//             onChange={() => handleCheckboxChange(col)}
//           />
//           <label>{col}</label>
//         </div>
//       ))}
//     </div>
//   );
// }

// export default ColumnSelector;

import { useEffect, useState } from 'react';

function ColumnSelector({ columns, setColumns }) {
  const [availableColumns, setAvailableColumns] = useState([
    'id', 'name', 'email', 'amount', 'created_at' // 🧪 Simulated
  ]);

  const handleCheckboxChange = (column) => {
    setColumns((prev) =>
      prev.includes(column)
        ? prev.filter((col) => col !== column)
        : [...prev, column]
    );
  };

  return (
    <div className="column-selector">
      <h2>3. Select Columns</h2>
      <div className="columns-container">
        {availableColumns.map((col) => (
          <div key={col} className="column-item">
            <input
              type="checkbox"
              id={`col-${col}`}
              checked={columns.includes(col)}
              onChange={() => handleCheckboxChange(col)}
              className="column-checkbox"
            />
            <label htmlFor={`col-${col}`} className="column-label">
              {col}
            </label>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ColumnSelector;