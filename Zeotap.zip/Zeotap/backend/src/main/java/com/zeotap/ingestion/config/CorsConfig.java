package com.zeotap.ingestion.config;

public class CorsConfig {
    
}
