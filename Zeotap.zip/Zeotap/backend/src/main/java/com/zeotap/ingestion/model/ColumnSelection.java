package com.zeotap.ingestion.model;

public class ColumnSelection {
    
}
