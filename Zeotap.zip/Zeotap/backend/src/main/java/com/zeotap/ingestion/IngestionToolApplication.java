package com.zeotap.ingestion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngestionToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngestionToolApplication.class, args);
	}

}
