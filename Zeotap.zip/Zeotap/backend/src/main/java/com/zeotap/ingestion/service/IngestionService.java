package com.zeotap.ingestion.service;

import com.zeotap.ingestion.model.ClickHouseConfig;
import com.zeotap.ingestion.model.FlatFileConfig;
import com.zeotap.ingestion.model.IngestionRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.*;

@Service
public class IngestionService {

    @Autowired
    private ClickHouseService clickHouseService;

    @Autowired
    private FlatFileService flatFileService;

    // ✅ ClickHouse -> FlatFile
    public int ingestClickHouseToFlatFile(ClickHouseConfig clickHouseConfig, FlatFileConfig flatFileConfig, String tableName, List<String> selectedColumns) throws Exception {
        String query = buildSelectQuery(tableName, selectedColumns);

        List<Map<String, String>> data = new ArrayList<>();

        try (Connection conn = clickHouseService.createConnection(clickHouseConfig);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Map<String, String> row = new HashMap<>();
                for (String col : selectedColumns) {
                    row.put(col, rs.getString(col));
                }
                data.add(row);
            }
        }

        flatFileService.writeData(flatFileConfig, data, selectedColumns);
        return data.size();
    }

    // ✅ FlatFile -> ClickHouse
    public int ingestFlatFileToClickHouse(FlatFileConfig flatFileConfig, ClickHouseConfig clickHouseConfig, String targetTable, List<String> selectedColumns) throws Exception {
        List<Map<String, String>> data = flatFileService.readData(flatFileConfig, selectedColumns);

        try (Connection conn = clickHouseService.createConnection(clickHouseConfig)) {
            conn.setAutoCommit(false);
            String insertQuery = buildInsertQuery(targetTable, selectedColumns);

            try (PreparedStatement stmt = conn.prepareStatement(insertQuery)) {
                for (Map<String, String> row : data) {
                    for (int i = 0; i < selectedColumns.size(); i++) {
                        stmt.setString(i + 1, row.get(selectedColumns.get(i)));
                    }
                    stmt.addBatch();
                }
                stmt.executeBatch();
                conn.commit();
            }
        }

        return data.size();
    }

    private String buildSelectQuery(String tableName, List<String> selectedColumns) {
        return "SELECT " + String.join(", ", selectedColumns) + " FROM " + tableName;
    }

    private String buildInsertQuery(String tableName, List<String> selectedColumns) {
        String columns = String.join(", ", selectedColumns);
        String placeholders = String.join(", ", Collections.nCopies(selectedColumns.size(), "?"));
        return "INSERT INTO " + tableName + " (" + columns + ") VALUES (" + placeholders + ")";
    }

    public int handleIngestion(IngestionRequest request) throws Exception {
    String sourceType = request.getSourceType();
    String targetType = request.getTargetType();

    if ("ClickHouse".equalsIgnoreCase(sourceType) && "FlatFile".equalsIgnoreCase(targetType)) {
        return ingestClickHouseToFlatFile(
            request.getClickHouseConfig(),
            request.getFlatFileConfig(),
            request.getTableName(),
            request.getSelectedColumns()
        );
    } else if ("FlatFile".equalsIgnoreCase(sourceType) && "ClickHouse".equalsIgnoreCase(targetType)) {
        return ingestFlatFileToClickHouse(
            request.getFlatFileConfig(),
            request.getClickHouseConfig(),
            request.getTableName(),
            request.getSelectedColumns()
        );
    } else {
        throw new IllegalArgumentException("Invalid source/target combination.");
    }
}

}
