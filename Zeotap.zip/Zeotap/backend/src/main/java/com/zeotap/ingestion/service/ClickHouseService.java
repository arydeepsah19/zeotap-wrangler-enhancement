package com.zeotap.ingestion.service;

import com.zeotap.ingestion.model.ClickHouseConfig;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

@Service
public class ClickHouseService {

    public Connection createConnection(ClickHouseConfig config) throws Exception {
        String url = "jdbc:clickhouse://" + config.getHost() + ":" + config.getPort() + "/" + config.getDatabase();
        Properties props = new Properties();
        props.setProperty("user", config.getUser());
        props.setProperty("password", config.getJwtToken()); // Token used as password

        return DriverManager.getConnection(url, props);
    }

    public List<String> fetchTableNames(ClickHouseConfig config) throws Exception {
        List<String> tables = new ArrayList<>();
        String query = "SHOW TABLES";

        try (Connection conn = createConnection(config);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                tables.add(rs.getString(1));
            }
        }

        return tables;
    }

    public List<String> fetchColumnNames(ClickHouseConfig config, String tableName) throws Exception {
        List<String> columns = new ArrayList<>();
        String query = "DESCRIBE TABLE " + tableName;

        try (Connection conn = createConnection(config);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                columns.add(rs.getString("name"));
            }
        }

        return columns;
    }

    // TODO: Add method for fetching data based on selected columns
    // TODO: Add method for inserting data into ClickHouse

}
