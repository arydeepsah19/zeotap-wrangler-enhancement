package com.zeotap.ingestion.controller;

import com.zeotap.ingestion.model.IngestionRequest;
import com.zeotap.ingestion.service.IngestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ingest")
@CrossOrigin(origins = "*") // Allow frontend access
public class IngestionController {

    @Autowired
    private IngestionService ingestionService;

    @PostMapping
    public ResponseEntity<?> ingestData(@RequestBody IngestionRequest request) {
        try {
            int recordCount = ingestionService.handleIngestion(request);
            return ResponseEntity.ok("Ingestion successful. Records processed: " + recordCount);
        } catch (Exception e) {
            e.printStackTrace(); // Add this for detailed error in console
            return ResponseEntity.status(500).body("Ingestion failed: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
        }
    }

    @GetMapping("/test")
    public ResponseEntity<String> testEndpoint() {
        return ResponseEntity.ok("Ingestion service is up and running!");
    }
}
