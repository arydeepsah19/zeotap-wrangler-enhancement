package com.zeotap.ingestion.service;

import com.zeotap.ingestion.model.FlatFileConfig;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.*;

@Service
public class FlatFileService {

    public List<String> getColumnNames(FlatFileConfig config) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(config.getFileName()))) {
            String headerLine = reader.readLine();
            if (headerLine == null) {
                throw new IOException("Flat file is empty or missing headers.");
            }
            return Arrays.asList(headerLine.split(config.getDelimiter()));
        }
    }

    public List<Map<String, String>> readData(FlatFileConfig config, List<String> selectedColumns) throws IOException {
        List<Map<String, String>> data = new ArrayList<>();
        List<String> allColumns;

        try (BufferedReader reader = new BufferedReader(new FileReader(config.getFileName()))) {
            String headerLine = reader.readLine();
            if (headerLine == null) return data;

            allColumns = Arrays.asList(headerLine.split(config.getDelimiter()));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] values = line.split(config.getDelimiter());
                Map<String, String> row = new HashMap<>();

                for (int i = 0; i < allColumns.size() && i < values.length; i++) {
                    String column = allColumns.get(i);
                    if (selectedColumns.contains(column)) {
                        row.put(column, values[i]);
                    }
                }

                data.add(row);
            }
        }

        return data;
    }

    public void writeData(FlatFileConfig config, List<Map<String, String>> data, List<String> selectedColumns) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(config.getFileName()))) {
            // Write header
            writer.write(String.join(config.getDelimiter(), selectedColumns));
            writer.newLine();

            // Write rows
            for (Map<String, String> row : data) {
                List<String> values = new ArrayList<>();
                for (String col : selectedColumns) {
                    values.add(row.getOrDefault(col, ""));
                }
                writer.write(String.join(config.getDelimiter(), values));
                writer.newLine();
            }
        }
    }
}
