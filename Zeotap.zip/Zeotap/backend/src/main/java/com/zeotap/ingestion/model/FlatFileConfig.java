package com.zeotap.ingestion.model;

public class FlatFileConfig {

    private String filePath;  // Keep the field name as filePath
    private String delimiter;

    // Getter for filePath (for backwards compatibility)
    public String getFileName() {
        return filePath;
    }

    // Standard getter and setter for filePath
    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getDelimiter() {
        return delimiter;
    }

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }

    @Override
    public String toString() {
        return "FlatFileConfig{" +
                "filePath='" + filePath + '\'' +
                ", delimiter='" + delimiter + '\'' +
                '}';
    }
}
