package com.zeotap.ingestion.model;

import java.util.List;

public class IngestionRequest {

    private String sourceType;  // "clickhouse" or "flatfile"
    private String targetType;  // "clickhouse" or "flatfile"

    private ClickHouseConfig clickHouseConfig;
    private FlatFileConfig flatFileConfig;

    private List<String> selectedColumns;
    private String tableName;
    private String joinQuery; // Optional - for multi-table joins

    // Getters and setters

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getTargetType() {
        return targetType;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    public ClickHouseConfig getClickHouseConfig() {
        return clickHouseConfig;
    }

    public void setClickHouseConfig(ClickHouseConfig clickHouseConfig) {
        this.clickHouseConfig = clickHouseConfig;
    }

    public FlatFileConfig getFlatFileConfig() {
        return flatFileConfig;
    }

    public void setFlatFileConfig(FlatFileConfig flatFileConfig) {
        this.flatFileConfig = flatFileConfig;
    }

    public List<String> getSelectedColumns() {
        return selectedColumns;
    }

    public void setSelectedColumns(List<String> selectedColumns) {
        this.selectedColumns = selectedColumns;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getJoinQuery() {
        return joinQuery;
    }

    public void setJoinQuery(String joinQuery) {
        this.joinQuery = joinQuery;
    }

    @Override
    public String toString() {
        return "IngestionRequest{" +
                "sourceType='" + sourceType + '\'' +
                ", targetType='" + targetType + '\'' +
                ", tableName='" + tableName + '\'' +
                ", selectedColumns=" + selectedColumns +
                '}';
    }
}
