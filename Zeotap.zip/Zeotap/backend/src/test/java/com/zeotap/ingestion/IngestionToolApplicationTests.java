package com.zeotap.ingestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IngestionToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
